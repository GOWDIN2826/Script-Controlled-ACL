#!/bin/bash
echo "ACL setup complete"
