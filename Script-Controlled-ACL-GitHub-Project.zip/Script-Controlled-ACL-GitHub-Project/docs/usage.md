# Usage
Use the scripts folder to check and configure ACL settings.
