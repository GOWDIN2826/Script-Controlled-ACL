# Installation
1. Extract the project.
2. Review ACL rules.
3. Run the setup script.
