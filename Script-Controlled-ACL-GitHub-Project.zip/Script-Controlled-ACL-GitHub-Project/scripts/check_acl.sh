#!/bin/bash
echo "Checking ACL rules..."
