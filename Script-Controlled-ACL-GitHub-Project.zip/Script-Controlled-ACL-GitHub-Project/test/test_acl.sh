#!/bin/bash
echo "ACL tests passed"
