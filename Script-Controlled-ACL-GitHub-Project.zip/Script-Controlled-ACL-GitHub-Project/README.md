# Script Controlled ACL GitHub Project

A simple project structure for script-controlled ACL management.

## Folders
- acl
- scripts
- test
- docs
- database
